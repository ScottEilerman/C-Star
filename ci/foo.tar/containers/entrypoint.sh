#!/bin/bash
source /etc/profile
exec "$@"
